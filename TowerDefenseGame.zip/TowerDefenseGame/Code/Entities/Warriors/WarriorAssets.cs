using Microsoft.Xna.Framework.Graphics;

namespace TowerDefenseGame
{
    public class WarriorAssets
    {
        public Texture2D WalkTexture { get; set; }
        public Texture2D AttackTexture { get; set; }
        public Texture2D DeathTexture { get; set; }

        public Texture2D EliteWalkTexture { get; set; }
        public Texture2D EliteAttackTexture { get; set; }
        public Texture2D EliteDeathTexture { get; set; }
    }
}
