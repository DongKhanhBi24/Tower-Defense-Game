
namespace TowerDefenseGame
{
    public interface IEnemyMovement
    {
        bool Move(Enemy enemy, float deltaTime);
    }
}
