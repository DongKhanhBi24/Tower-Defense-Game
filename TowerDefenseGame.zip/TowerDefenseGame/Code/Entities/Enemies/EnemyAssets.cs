using Microsoft.Xna.Framework.Graphics;

namespace TowerDefenseGame
{
    public class EnemyAssets
    {
        public Texture2D SpriteSheet { get; set; }
        public int FrameWidth { get; set; }
        public int FrameHeight { get; set; }
        public int FrameCount { get; set; }
        public float FrameTime { get; set; }
    }
}
