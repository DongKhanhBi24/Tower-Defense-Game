using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace TowerDefenseGame
{
    public class MagicTowerAssets
    {
        public Dictionary<string, Texture2D> MagicTextures { get; set; }
    }
}
