﻿using var game = new TowerDefenseGame.Game1();
game.Run();
